## Copyright (C) 2022 Andrei
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <https://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {} {@var{retval} =} QR_fd (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: Andrei <Andrei@DESKTOP-PK505U9>
## Created: 2022-04-30

function [eig_val] = QR_fd (a, b, max_iter)
  n = length (a);
  A = diag (a) + diag (b, 1) + diag(b, -1);
  
  for iter = 1:max_iter
    Q = eye (n);
    for i = 2:n
      P = eye (n);
      ro = sqrt (A(i-1, i-1)^2 + A(i, i-1)^2);
      c = A(i-1, i-1) / ro;
      s = -A(i, i-1) / ro;
      P(i-1, i-1) = c;
      P(i-1, i) = -s;
      P(i, i-1) = s;
      P(i, i) = c;
      Q = P * Q;
      A = P * A;
    endfor
    
    Q = Q'
    R = A
    A = R * Q
  endfor
  
  eig_val = diag(A);
  
endfunction
