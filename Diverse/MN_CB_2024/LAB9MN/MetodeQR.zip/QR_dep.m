## Copyright (C) 2022 Andrei
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <https://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {} {@var{retval} =} QR_dep (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: Andrei <Andrei@DESKTOP-PK505U9>
## Created: 2022-04-30

function [eig_val] = QR_dep (a, b, tol)
  n = length (a);
  eig_val = zeros (1, n);
  A = diag(a) + diag(b, 1) + diag(b, -1);
  m = n;
  
  for i = 1:n-2
    while true
      Q = eye(m);
      E = A(m-1:m, m-1:m);
      lambda = eig(E);
      sigma = 0;
    
      if abs (lambda(1) - A(m, m)) < abs (lambda(2) - A(m, m))
        sigma = lambda(1);
      else
        sigma = lambda(2);
      endif
      A = A - sigma * eye(m);
    
      for j = 2:m
        ro = sqrt (A(j-1, j-1)^2 + A(j, j-1)^2);
        c = A(j-1, j-1) / ro;
        s = -A(j, j-1) / ro;
        P = eye(m);
        P(j-1, j-1) = c;
        P(j, j-1) = s;
        P(j-1, j) = -s;
        P(j, j) = c;
        Q = P * Q;
        A = P * A;
      endfor
      
      Q = Q';
      R = A;
      R * Q
      A = R * Q + sigma * eye(m)
    
      if abs (A(m, m-1)) < tol
        eig_val(i) = A(m, m);
        A = A(1:m-1, 1:m-1)
        m = m - 1;
        break;
      endif
    endwhile
  endfor
  
  lambda = eig(A);
  eig_val (n-1) = lambda(2);
  eig_val (n) = lambda (1);

endfunction
